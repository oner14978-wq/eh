//! A player's advancements on a server (PlayerAdvancements): on the
//! player's first tick the `minecraft:tick` criteria are met, the
//! advancements they complete grant their recipes (ServerRecipeBook.addRecipes:
//! ClientboundRecipeBookAddPacket) and the advancements the player may see go
//! out in ClientboundUpdateAdvancementsPacket (PlayerAdvancements.flushDirty).
use super::data::{SyncData, json_to_nbt};
use crate::{
    advancements::{Progress, Tree},
    recipe_book::{Category, RecipeIndex, Settings, crafting_category, crafting_station},
};
use horizon_protocol::buf::Writer;
use serde_json::Value;
use std::{
    collections::{BTreeMap, BTreeSet, HashMap},
    path::Path,
};

#[derive(Clone)]
pub struct ServerAdvancements {
    tree: std::sync::Arc<Tree>,
    kids: Vec<Vec<usize>>,
    layout: Vec<Option<(i32, f32)>>,
    /// Recipe files by id, as compact JSON text with their ingredient
    /// objects already resolved to flat item lists (`network_recipes`): a
    /// book entry parses its recipe when a player gets it (a few µs), and
    /// the ~1,400 parsed files would keep about 5 MB alive for the server's
    /// whole run.
    pub(super) recipes: BTreeMap<String, Box<str>>,
    displays: RecipeIndex,
    /// RecipeManager.unpackRecipeInfo's group numbers.
    groups: HashMap<String, i32>,
}

/// What the first tick sends: ClientboundRecipeBookAddPacket's payload (when
/// recipes were unlocked) and ClientboundUpdateAdvancementsPacket's.
pub struct FirstTick {
    pub recipe_book_add: Option<Vec<u8>>,
    pub update_advancements: Vec<u8>,
    pub granted: Vec<CriterionGrant>,
}

/// A criterion `CriteriaTriggers.TICK` newly granted, for the game to tell the mods.
#[derive(Clone)]
pub struct CriterionGrant {
    pub advancement: String,
    pub criterion: String,
}

impl ServerAdvancements {
    pub fn load(
        resources: &Path,
        overlay: &horizon_world::loot::PackOverlay,
        recipes: BTreeMap<String, Box<str>>,
        groups: HashMap<String, i32>,
    ) -> Self {
        let tree = Tree::shared(&resources.join("data"), overlay);
        let kids = tree.children();
        let layout = tree.layout();
        Self {
            tree,
            kids,
            layout,
            recipes,
            displays: RecipeIndex::load(resources, overlay),
            groups,
        }
    }

    /// The loaded definition whose criteria and requirements the player's progress uses.
    pub fn definition(&self, id: &str) -> Option<&crate::advancements::Advancement> {
        self.tree.get(id)
    }

    /// The unconditional tick criteria in tree order. A caller grants these one
    /// at a time so it can notify mods before applying each completion's rewards.
    pub fn tick_candidates(&self, progress: &Progress) -> Vec<CriterionGrant> {
        let mut candidates = Vec::new();
        for advancement in &self.tree.list {
            if progress.done(advancement) {
                continue;
            }
            for criterion in &advancement.criteria {
                if criterion.trigger == "minecraft:tick"
                    && criterion.conditions.is_null()
                    && !progress.has(&advancement.id, &criterion.name)
                {
                    candidates.push(CriterionGrant {
                        advancement: advancement.id.clone(),
                        criterion: criterion.name.clone(),
                    });
                }
            }
        }
        candidates
    }

    /// Grant one candidate, returning whether its advancement was already complete.
    /// Recheck against the live tree and progress: a preceding hook may have changed either.
    pub fn grant_tick(
        &self,
        progress: &mut Progress,
        grant: &CriterionGrant,
        now_millis: i64,
    ) -> Option<bool> {
        let advancement = self.tree.list.iter().find(|a| a.id == grant.advancement)?;
        if progress.done(advancement)
            || !advancement.criteria.iter().any(|c| {
                c.name == grant.criterion && c.trigger == "minecraft:tick" && c.conditions.is_null()
            })
        {
            return None;
        }
        let was_done = progress.done(advancement);
        let date = crate::advancements::date_text(now_millis.div_euclid(1000));
        progress
            .grant(&advancement.id, &grant.criterion, &date)
            .then_some(was_done)
    }

    /// Complete the grant after the listener returns, if it still completes the advancement.
    pub fn reward_tick(
        &self,
        sync: &SyncData,
        progress: &Progress,
        book: &mut Settings,
        grant: &CriterionGrant,
        was_done: bool,
    ) -> Option<Vec<u8>> {
        let advancement = self.tree.list.iter().find(|a| a.id == grant.advancement)?;
        if was_done || !progress.done(advancement) {
            return None;
        }
        book.add_recipes(&self.displays, &advancement.rewards.recipes);
        let entries = advancement
            .rewards
            .recipes
            .iter()
            .flat_map(|id| self.book_entries(id, sync, NOTIFY_AND_HIGHLIGHT))
            .collect::<Vec<_>>();
        (!entries.is_empty()).then(|| book_add(entries, false))
    }

    /// Drop progress for advancements or criteria absent from the reloaded tree.
    pub fn prune_progress(&self, progress: &mut Progress) {
        let by_id: HashMap<&str, &crate::advancements::Advancement> =
            self.tree.list.iter().map(|a| (a.id.as_str(), a)).collect();
        progress
            .criteria
            .retain(|id, got| match by_id.get(id.as_str()) {
                Some(a) => {
                    got.retain(|name, _| a.criteria.iter().any(|c| &c.name == name));
                    true
                }
                None => false,
            });
    }

    /// The first tick of a player without advancements: the criteria
    /// `minecraft:tick` meets go into `progress` and the recipes their
    /// advancements reward into `book`.
    pub fn first_tick(
        &self,
        sync: &SyncData,
        now_millis: i64,
        progress: &mut Progress,
        book: &mut Settings,
    ) -> FirstTick {
        // CriteriaTriggers.TICK: the criteria it meets, and what they complete.
        let mut obtained: Vec<Vec<&str>> = vec![Vec::new(); self.tree.list.len()];
        for (i, a) in self.tree.list.iter().enumerate() {
            for c in &a.criteria {
                if c.trigger == "minecraft:tick" && c.conditions.is_null() {
                    obtained[i].push(&c.name);
                }
            }
        }
        let done: Vec<bool> = self
            .tree
            .list
            .iter()
            .zip(&obtained)
            .map(|(a, got)| {
                !a.requirements.is_empty()
                    && a.requirements
                        .iter()
                        .all(|group| group.iter().any(|c| got.contains(&c.as_str())))
            })
            .collect();
        let date = crate::advancements::date_text(now_millis.div_euclid(1000));
        let mut granted = Vec::new();
        for (a, got) in self.tree.list.iter().zip(&obtained) {
            for c in got {
                if progress.grant(&a.id, c, &date) {
                    granted.push(CriterionGrant {
                        advancement: a.id.clone(),
                        criterion: (*c).to_owned(),
                    });
                }
            }
        }
        // AdvancementRewards.grant: the recipes, in the advancements' order.
        let mut entries = Vec::new();
        for (i, a) in self.tree.list.iter().enumerate() {
            if !done[i] {
                continue;
            }
            book.add_recipes(&self.displays, &a.rewards.recipes);
            for id in &a.rewards.recipes {
                entries.extend(self.book_entries(id, sync, NOTIFY_AND_HIGHLIGHT));
            }
        }
        let recipe_book_add = (!entries.is_empty()).then(|| book_add(entries, false));
        // flushDirty: every advancement the player may see, and its progress.
        let visible = self.tree.visible(&self.kids, |i| done[i]);
        let shown: Vec<usize> = (0..self.tree.list.len()).filter(|i| visible[*i]).collect();
        let mut w = Writer::new();
        w.bool(true); // the first packet resets the client's advancements
        w.varint(shown.len() as i32);
        for &i in &shown {
            self.write_advancement(&mut w, i, sync);
        }
        w.varint(0); // nothing removed
        w.varint(shown.len() as i32);
        for &i in &shown {
            self.write_progress(&mut w, i, |c| {
                obtained[i].contains(&c).then_some(now_millis)
            });
        }
        w.bool(true); // show the advancements
        FirstTick {
            recipe_book_add,
            update_advancements: w.data,
            granted,
        }
    }

    /// `RecipeManager.getRecipeFromDisplay`: the recipe a display id names,
    /// for `ServerRecipeBook.removeHighlight`.
    pub fn recipe_of_display(&self, display: i32) -> Option<&str> {
        self.displays.recipe_of_display(display)
    }

    /// `PlayerAdvancements.reload` (`PlayerList.reloadResources`): the
    /// progress is read again against the new tree (`applyFrom` ignores an
    /// advancement that no longer exists and `AdvancementProgress.update`
    /// drops a criterion it lost), the next `flushDirty` is a first packet
    /// again, and the next `CriteriaTriggers.TICK` meets the new tree's
    /// `minecraft:tick` criteria, rewarding the recipes of the advancements
    /// that complete. The criteria it grants are added to `granted`. Returns
    /// the recipe book packet those recipes need.
    pub fn reload(
        &self,
        sync: &SyncData,
        now_millis: i64,
        progress: &mut Progress,
        book: &mut Settings,
        granted: &mut Vec<CriterionGrant>,
    ) -> Option<Vec<u8>> {
        self.prune_progress(progress);
        let date = crate::advancements::date_text(now_millis.div_euclid(1000));
        let mut entries = Vec::new();
        for a in &self.tree.list {
            let was_done = progress.done(a);
            for c in &a.criteria {
                if c.trigger == "minecraft:tick"
                    && c.conditions.is_null()
                    && progress.grant(&a.id, &c.name, &date)
                {
                    granted.push(CriterionGrant {
                        advancement: a.id.clone(),
                        criterion: c.name.clone(),
                    });
                }
            }
            if !was_done && progress.done(a) {
                book.add_recipes(&self.displays, &a.rewards.recipes);
                for id in &a.rewards.recipes {
                    entries.extend(self.book_entries(id, sync, NOTIFY_AND_HIGHLIGHT));
                }
            }
        }
        (!entries.is_empty()).then(|| book_add(entries, false))
    }

    /// `PlayerAdvancements.flushDirty`: the advancements that became visible
    /// or hidden since `visible` (which it updates; empty before the first
    /// packet, which resets the client's and carries everything visible) and
    /// the progress of the `changed` ones still visible. None when there is
    /// nothing to send.
    pub fn update(
        &self,
        sync: &SyncData,
        progress: &Progress,
        visible: &mut Vec<bool>,
        changed: &BTreeSet<usize>,
        show: bool,
    ) -> Option<Vec<u8>> {
        let n = self.tree.list.len();
        let first = visible.len() != n;
        // flushDirty does nothing unless it is the first packet or progress
        // changed: visibility follows progress alone, and every grant and
        // revoke is in `changed`. This skips walking the whole tree for
        // every player every tick.
        if !first && changed.is_empty() {
            return None;
        }
        let now = self
            .tree
            .visible(&self.kids, |i| progress.done(&self.tree.list[i]));
        let was = |i: usize| !first && visible[i];
        let added: Vec<usize> = (0..n).filter(|&i| now[i] && !was(i)).collect();
        let removed: Vec<usize> = (0..n).filter(|&i| !now[i] && was(i)).collect();
        let progressed: Vec<usize> = if first {
            (0..n).filter(|&i| now[i]).collect()
        } else {
            changed
                .iter()
                .copied()
                .filter(|&i| i < n && now[i])
                .collect()
        };
        *visible = now;
        if !first && added.is_empty() && removed.is_empty() && progressed.is_empty() {
            return None;
        }
        let mut w = Writer::new();
        w.bool(first);
        w.varint(added.len() as i32);
        for &i in &added {
            self.write_advancement(&mut w, i, sync);
        }
        w.varint(removed.len() as i32);
        for &i in &removed {
            w.string(&self.tree.list[i].id);
        }
        w.varint(progressed.len() as i32);
        for &i in &progressed {
            let id = &self.tree.list[i].id;
            self.write_progress(&mut w, i, |c| {
                progress
                    .criteria
                    .get(id)
                    .and_then(|m| m.get(c))
                    .map(|date| crate::advancements::date_millis(date).unwrap_or(0))
            });
        }
        w.bool(show);
        Some(w.data)
    }

    /// `ServerAdvancementManager.get` then `PlayerAdvancements.setSelectedTab`:
    /// `None` when the server has no advancement `id` (the tab is left as it
    /// is), else whether a player may keep it as its tab (a root that has a
    /// display).
    pub fn selectable(&self, id: &str) -> Option<bool> {
        self.tree
            .get(id)
            .map(|a| a.parent.is_none() && a.display.is_some())
    }

    /// Initial reset after staged first-tick grants. Fresh criteria keep the
    /// millisecond timestamp from the tick; older progress keeps its saved date.
    pub fn first_snapshot(
        &self,
        sync: &SyncData,
        progress: &Progress,
        fresh: &[CriterionGrant],
        now_millis: i64,
    ) -> (Vec<u8>, Vec<bool>) {
        let visible = self.visibility(progress);
        let shown: Vec<_> = (0..self.tree.list.len()).filter(|&i| visible[i]).collect();
        let mut w = Writer::new();
        w.bool(true);
        w.varint(shown.len() as i32);
        for &i in &shown {
            self.write_advancement(&mut w, i, sync);
        }
        w.varint(0);
        w.varint(shown.len() as i32);
        for &i in &shown {
            let id = &self.tree.list[i].id;
            self.write_progress(&mut w, i, |criterion| {
                let date = progress.criteria.get(id)?.get(criterion)?;
                if fresh
                    .iter()
                    .any(|g| &g.advancement == id && g.criterion == criterion)
                    && *date == crate::advancements::date_text(now_millis.div_euclid(1000))
                {
                    Some(now_millis)
                } else {
                    Some(crate::advancements::date_millis(date).unwrap_or(0))
                }
            });
        }
        w.bool(true);
        (w.data, visible)
    }

    /// Which advancements a player with `progress` may see.
    pub fn visibility(&self, progress: &Progress) -> Vec<bool> {
        self.tree
            .visible(&self.kids, |i| progress.done(&self.tree.list[i]))
    }

    /// `ClientboundUpdateAdvancementsPacket.PositionedAdvancement`.
    fn write_advancement(&self, w: &mut Writer, i: usize, sync: &SyncData) {
        let a = &self.tree.list[i];
        w.string(&a.id);
        w.bool(a.parent.is_some());
        if let Some(p) = &a.parent {
            w.string(p);
        }
        w.bool(a.display.is_some());
        if let Some(d) = &a.display {
            w.nbt(&json_to_nbt(&d.title));
            w.nbt(&json_to_nbt(&d.description));
            w.varint(sync.id("minecraft:item", &d.icon).unwrap_or(0));
            w.varint(1);
            w.varint(0);
            w.varint(0);
            w.varint(match d.frame {
                crate::advancements::Frame::Task => 0,
                crate::advancements::Frame::Challenge => 1,
                crate::advancements::Frame::Goal => 2,
            });
            w.i32(
                i32::from(d.background.is_some())
                    | i32::from(d.show_toast) << 1
                    | i32::from(d.hidden) << 2,
            );
            if let Some(b) = &d.background {
                w.string(b);
            }
        }
        w.varint(a.requirements.len() as i32);
        for group in &a.requirements {
            w.varint(group.len() as i32);
            for c in group {
                w.string(c);
            }
        }
        w.bool(false); // sends_telemetry_event
        let (x, y) = self.layout[i].unwrap_or((0, 0.0));
        w.f32(x as f32);
        w.f32(y);
    }

    /// An `AdvancementProgress`: each criterion and when it was obtained.
    fn write_progress(&self, w: &mut Writer, i: usize, obtained: impl Fn(&str) -> Option<i64>) {
        let a = &self.tree.list[i];
        w.string(&a.id);
        w.varint(a.criteria.len() as i32);
        for c in &a.criteria {
            w.string(&c.name);
            let at = obtained(&c.name);
            w.bool(at.is_some());
            if let Some(at) = at {
                w.i64(at);
            }
        }
    }

    /// `ServerRecipeBook.addRecipes`' packet for recipes just unlocked:
    /// each display, with its notification and highlighted. None when no
    /// recipe has a display.
    pub fn recipes_added(&self, ids: &[String], sync: &SyncData) -> Option<Vec<u8>> {
        let entries: Vec<Vec<u8>> = ids
            .iter()
            .flat_map(|id| self.book_entries(id, sync, NOTIFY_AND_HIGHLIGHT))
            .collect();
        (!entries.is_empty()).then(|| book_add(entries, false))
    }

    /// `ServerRecipeBook.sendInitialRecipeBook`: every known recipe, without
    /// notifications, highlighted while not yet displayed, replacing the
    /// client's book.
    pub fn initial_recipe_book(&self, book: &Settings, sync: &SyncData) -> Vec<u8> {
        let entries: Vec<Vec<u8>> = book
            .recipes
            .iter()
            .flat_map(|id| {
                let highlight = if book.to_be_displayed.contains(id) {
                    2
                } else {
                    0
                };
                self.book_entries(id, sync, highlight)
            })
            .collect();
        book_add(entries, true)
    }

    /// The recipe's display for ClientboundPlaceGhostRecipePacket (the
    /// recipes the book lists).
    pub fn ghost_display(
        &self,
        id: &str,
        sync: &SyncData,
    ) -> Option<horizon_protocol::packets::recipes::RecipeDisplay> {
        // A recipe with several displays has no ghost here (PlaceRecipe is
        // not this change's): only a single-display recipe's entry is used.
        if self.displays.display_ids(id).len() != 1 {
            return None;
        }
        let bytes = self.book_entries(id, sync, 0).into_iter().next()?;
        let mut r = horizon_protocol::buf::Reader::new(&bytes);
        horizon_protocol::packets::recipes::RecipeBookEntry::read(&mut r)
            .ok()
            .map(|e| e.display)
    }

    /// ClientboundRecipeBookAddPacket.Entry for each display of a recipe:
    /// highlighted, and with a notification unless the recipe turns it off.
    fn book_entries(&self, id: &str, sync: &SyncData, flags: i8) -> Vec<Vec<u8>> {
        let ids = self.displays.display_ids(id);
        let Some(r) = self
            .recipes
            .get(id)
            .and_then(|text| serde_json::from_str::<Value>(text).ok())
        else {
            return Vec::new();
        };
        let r = &r;
        if r["type"].as_str() == Some("minecraft:crafting_transmute") {
            return self
                .transmute_entries(r, ids, sync, flags)
                .unwrap_or_default();
        }
        if ids.len() != 1 {
            // Special recipes have no display.
            return Vec::new();
        }
        let kind = r["type"].as_str().unwrap_or("");
        let item = |n: &str| sync.id("minecraft:item", n);
        let slot = |n: &str| sync.id("minecraft:slot_display", n).unwrap_or(0);
        let mut w = Writer::new();
        w.varint(ids.start);
        // The ingredients' TagSlotDisplays, an empty cell as an empty slot.
        let slots = |w: &mut Writer, cells: &[Option<&Value>]| {
            w.varint(cells.len() as i32);
            for cell in cells {
                match cell {
                    Some(v) => {
                        w.varint(slot("minecraft:tag"));
                        holder_set(w, v, &item);
                    }
                    None => w.varint(slot("minecraft:empty")),
                }
            }
        };
        // The result as its ItemStackSlotDisplay, the station as its item.
        let result = |w: &mut Writer| {
            w.varint(slot("minecraft:item_stack"));
            w.varint(
                item(
                    horizon_world::loot::recipe_result_id(&r["result"]).unwrap_or("minecraft:air"),
                )
                .unwrap_or(0),
            );
            w.varint(r["result"]["count"].as_i64().unwrap_or(1) as i32);
            w.varint(0);
            w.varint(0);
        };
        let station = |w: &mut Writer, name: &str| {
            w.varint(slot("minecraft:item"));
            w.varint(item(name).unwrap_or(0));
        };
        // The display, then the ingredients the craftable filter checks and
        // the category of the tab that lists it.
        let (category, placed): (&str, Vec<&Value>) = match kind {
            "minecraft:crafting_shaped" => {
                let pattern = shrink(r["pattern"].as_array().map_or(&[][..], |p| p));
                let (width, height) = (pattern.first().map_or(0, Vec::len), pattern.len());
                w.varint(sync.id("minecraft:recipe_display", kind).unwrap_or(0));
                w.varint(width as i32);
                w.varint(height as i32);
                let cells: Vec<Option<&Value>> = pattern
                    .iter()
                    .flatten()
                    .map(|c| (*c != ' ').then(|| &r["key"][c.to_string()]))
                    .collect();
                slots(&mut w, &cells);
                result(&mut w);
                station(&mut w, "minecraft:crafting_table");
                let placed = cells.iter().flatten().copied().collect();
                (
                    crafting_category(r["category"].as_str().unwrap_or("")).name(),
                    placed,
                )
            }
            "minecraft:crafting_shapeless" => {
                w.varint(sync.id("minecraft:recipe_display", kind).unwrap_or(0));
                let cells: Vec<Option<&Value>> = r["ingredients"]
                    .as_array()
                    .map_or(Vec::new(), |a| a.iter().map(Some).collect());
                slots(&mut w, &cells);
                result(&mut w);
                station(&mut w, "minecraft:crafting_table");
                let placed = cells.iter().flatten().copied().collect();
                (
                    crafting_category(r["category"].as_str().unwrap_or("")).name(),
                    placed,
                )
            }
            // AbstractCookingRecipe.display: the furnace, blast furnace,
            // smoker and campfire share one FurnaceRecipeDisplay; only the
            // station and the category differ.
            "minecraft:smelting"
            | "minecraft:blasting"
            | "minecraft:smoking"
            | "minecraft:campfire_cooking" => {
                w.varint(
                    sync.id("minecraft:recipe_display", "minecraft:furnace")
                        .unwrap_or(0),
                );
                w.varint(slot("minecraft:tag"));
                holder_set(&mut w, &r["ingredient"], &item);
                w.varint(slot("minecraft:any_fuel"));
                result(&mut w);
                station(&mut w, crafting_station(kind));
                w.varint(r["cookingtime"].as_i64().unwrap_or(0) as i32);
                w.f32(r["experience"].as_f64().unwrap_or(0.0) as f32);
                (cooking_category(kind, r), vec![&r["ingredient"]])
            }
            // DyeRecipe.display: the target, then the dyes kept to those with
            // the DYE component, shown as the demo of dyeing that target.
            // Its placement is the target and the dye.
            "minecraft:crafting_dye" => {
                let Some(dye_component) = sync.id("minecraft:data_component_type", "minecraft:dye")
                else {
                    return Vec::new();
                };
                let (target, dye) = (&r["target"], &r["dye"]);
                w.varint(
                    sync.id("minecraft:recipe_display", "minecraft:crafting_shapeless")
                        .unwrap_or(0),
                );
                w.varint(2);
                w.varint(slot("minecraft:tag"));
                holder_set(&mut w, target, &item);
                w.varint(slot("minecraft:only_with_component"));
                w.varint(slot("minecraft:tag"));
                holder_set(&mut w, dye, &item);
                w.varint(dye_component);
                w.varint(slot("minecraft:dyed"));
                w.varint(slot("minecraft:only_with_component"));
                w.varint(slot("minecraft:tag"));
                holder_set(&mut w, dye, &item);
                w.varint(dye_component);
                w.varint(slot("minecraft:tag"));
                holder_set(&mut w, target, &item);
                station(&mut w, "minecraft:crafting_table");
                (
                    crafting_category(r["category"].as_str().unwrap_or("")).name(),
                    vec![target, dye],
                )
            }
            // ImbueRecipe.display: four materials, the source kept to any
            // potion, four materials again, and the potion-wrapped result.
            // Its placement names the source in the middle cell.
            "minecraft:crafting_imbue" => {
                let (source, material) = (&r["source"], &r["material"]);
                w.varint(
                    sync.id("minecraft:recipe_display", "minecraft:crafting_shaped")
                        .unwrap_or(0),
                );
                w.varint(3);
                w.varint(3);
                w.varint(9);
                for cell in 0..9 {
                    if cell == 4 {
                        w.varint(slot("minecraft:with_any_potion"));
                    }
                    w.varint(slot("minecraft:tag"));
                    holder_set(&mut w, if cell == 4 { source } else { material }, &item);
                }
                w.varint(slot("minecraft:with_any_potion"));
                result(&mut w);
                station(&mut w, "minecraft:crafting_table");
                (
                    crafting_category(r["category"].as_str().unwrap_or("")).name(),
                    vec![
                        material, material, material, material, source, material, material,
                        material, material,
                    ],
                )
            }
            _ => return Vec::new(),
        };
        self.entry_tail(&mut w, r, sync, category, &placed, flags);
        vec![w.data]
    }

    /// An entry's end: the group, the recipe book category, the placement's
    /// ingredients and the flags.
    fn entry_tail(
        &self,
        w: &mut Writer,
        r: &Value,
        sync: &SyncData,
        category: &str,
        placed: &[&Value],
        flags: i8,
    ) {
        let item = |n: &str| sync.id("minecraft:item", n);
        match r["group"].as_str().and_then(|g| self.groups.get(g)) {
            Some(g) => w.varint(g + 1),
            None => w.varint(0),
        }
        let category = format!("minecraft:{category}");
        w.varint(
            sync.id("minecraft:recipe_book_category", &category)
                .unwrap_or(0),
        );
        w.bool(true);
        w.varint(placed.len() as i32);
        for v in placed {
            holder_set(w, v, &item);
        }
        // The notification only where the recipe shows one.
        let notify = r["show_notification"].as_bool().unwrap_or(true);
        w.i8(if notify { flags } else { flags & !1 });
    }

    /// `TransmuteRecipe.display`: one `ShapelessCraftingRecipeDisplay` per
    /// material count from the recipe's minimum to its maximum, the input
    /// then that many materials, its `resultDisplay`, the crafting table; the
    /// placement (`placementInfo`) is the input and the most materials. All
    /// or nothing: a form this cannot write, or a count that is not the
    /// recipe's display ids, gives no entry at all.
    fn transmute_entries(
        &self,
        r: &Value,
        ids: std::ops::Range<i32>,
        sync: &SyncData,
        flags: i8,
    ) -> Option<Vec<Vec<u8>>> {
        let (min, max) = crate::crafting::transmute_material_bounds(r.get("material_count"));
        if (max + 1).checked_sub(min)? != ids.len() {
            return None;
        }
        let item = |n: &str| sync.id("minecraft:item", n);
        let slot = |n: &str| sync.id("minecraft:slot_display", n);
        let (input, material) = (&r["input"], &r["material"]);
        let holder = |v: &Value| matches!(v, Value::String(_));
        if !holder(input) || !holder(material) {
            return None;
        }
        // TransmuteResult: an item (or none: the input's own items), a count
        // (1) and components, which this does not write.
        let result = &r["result"];
        if result
            .get("components")
            .is_some_and(|c| !c.as_object().is_some_and(|o| o.is_empty()))
        {
            return None;
        }
        let base = result["count"].as_i64().unwrap_or(1) as i32;
        let add = r["add_material_count_to_result"].as_bool().unwrap_or(false);
        let result_items: Vec<i32> = match result["id"].as_str() {
            Some(id) => vec![item(id)?],
            // Composite over the input's items, in the order clients get the tag.
            None => match input.as_str()? {
                tag if tag.starts_with('#') => {
                    let name = &tag[1..];
                    sync.tags
                        .registries
                        .iter()
                        .find(|t| t.registry == "minecraft:item")?
                        .tags
                        .iter()
                        .find(|t| t.name == name)?
                        .ids
                        .clone()
                }
                one => vec![item(one)?],
            },
        };
        let (shapeless, tag, empty_stack) = (
            sync.id("minecraft:recipe_display", "minecraft:crafting_shapeless")?,
            slot("minecraft:tag")?,
            slot("minecraft:item_stack")?,
        );
        let (composite, item_slot) = (slot("minecraft:composite")?, slot("minecraft:item")?);
        let table = item("minecraft:crafting_table")?;
        let category = crafting_category(r["category"].as_str().unwrap_or("")).name();
        let placed: Vec<&Value> = std::iter::once(input)
            .chain(std::iter::repeat_n(material, max))
            .collect();
        let mut entries = Vec::with_capacity(ids.len());
        for (n, id) in (min..=max).zip(ids) {
            let mut w = Writer::new();
            w.varint(id);
            w.varint(shapeless);
            w.varint(n as i32 + 1);
            for v in std::iter::once(input).chain(std::iter::repeat_n(material, n)) {
                w.varint(tag);
                holder_set(&mut w, v, &item);
            }
            // computeResultSize: the materials added to the count, or not.
            let count = if add { n as i32 + base } else { base };
            let stack = |w: &mut Writer, id: i32| {
                w.varint(empty_stack);
                w.varint(id);
                w.varint(count);
                w.varint(0);
                w.varint(0);
            };
            match result["id"].as_str() {
                Some(_) => stack(&mut w, result_items[0]),
                None => {
                    w.varint(composite);
                    w.varint(result_items.len() as i32);
                    for &id in &result_items {
                        stack(&mut w, id);
                    }
                }
            }
            w.varint(item_slot);
            w.varint(table);
            self.entry_tail(&mut w, r, sync, category, &placed, flags);
            entries.push(w.data);
        }
        Some(entries)
    }
}

/// ClientboundRecipeBookAddPacket.Entry flags: notification, highlight.
const NOTIFY_AND_HIGHLIGHT: i8 = 1 | 2;

/// ClientboundRecipeBookAddPacket: the entries, then whether they replace the book.
fn book_add(entries: Vec<Vec<u8>>, replace: bool) -> Vec<u8> {
    let mut w = Writer::new();
    w.varint(entries.len() as i32);
    for e in entries {
        w.data.extend(e);
    }
    w.bool(replace);
    w.data
}

/// `SmeltingRecipe.recipeBookCategory` and the other cooking recipes': the
/// category of the station's book, from the recipe's `CookingBookCategory`.
fn cooking_category(kind: &str, r: &Value) -> &'static str {
    let category = match kind {
        // BlastingRecipe: a blocks tab, and one misc tab for the rest.
        "minecraft:blasting" => match r["category"].as_str() {
            Some("blocks") => Category::BlastBlocks,
            _ => Category::BlastMisc,
        },
        "minecraft:smoking" => Category::SmokerFood,
        // CampfireCookingRecipe: its own category, which no book's tab lists.
        "minecraft:campfire_cooking" => return "campfire",
        // SmeltingRecipe: blocks, food and misc, the default.
        _ => match r["category"].as_str() {
            Some("food") => Category::FurnaceFood,
            Some("blocks") => Category::FurnaceBlocks,
            _ => Category::FurnaceMisc,
        },
    };
    category.name()
}

/// ShapedRecipePattern.shrink: the pattern without blank border rows and columns.
fn shrink(rows: &[Value]) -> Vec<Vec<char>> {
    let rows: Vec<Vec<char>> = rows
        .iter()
        .map(|r| r.as_str().unwrap_or("").chars().collect())
        .collect();
    let used = |r: &Vec<char>| r.iter().any(|c| *c != ' ');
    let (Some(top), Some(bottom)) = (rows.iter().position(used), rows.iter().rposition(used))
    else {
        return Vec::new();
    };
    let rows = &rows[top..=bottom];
    let left = rows
        .iter()
        .filter_map(|r| r.iter().position(|c| *c != ' '))
        .min()
        .unwrap_or(0);
    let right = rows
        .iter()
        .filter_map(|r| r.iter().rposition(|c| *c != ' '))
        .max()
        .unwrap_or(0);
    rows.iter()
        .map(|r| {
            (left..=right)
                .map(|x| r.get(x).copied().unwrap_or(' '))
                .collect()
        })
        .collect()
}

/// ByteBufCodecs.holderSet for an ingredient: a tag by name, or the items.
/// An item the registries do not know is left out, not sent as id 0.
fn holder_set(w: &mut Writer, v: &Value, item: &dyn Fn(&str) -> Option<i32>) {
    match v {
        Value::String(s) if s.starts_with('#') => {
            w.varint(0);
            w.string(&s[1..]);
        }
        Value::String(s) => match item(s) {
            Some(id) => {
                w.varint(2);
                w.varint(id);
            }
            None => w.varint(1),
        },
        Value::Array(a) => {
            let ids: Vec<i32> = a.iter().filter_map(|s| item(s.as_str()?)).collect();
            w.varint(ids.len() as i32 + 1);
            for id in ids {
                w.varint(id);
            }
        }
        _ => w.varint(1),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use horizon_protocol::{
        buf::Reader,
        item::Stack,
        packets::recipes::{HolderSet, RecipeBookEntry, RecipeDisplay, SlotDisplay},
    };
    use std::path::PathBuf;

    /// The registries `book_entries` looks up, in the game's order
    /// (`RecipeBookCategories` and the two display registries).
    const REGISTRIES: &str = r#"{
      "minecraft:item": {"entries": {
        "minecraft:raw_copper": {"protocol_id": 0},
        "minecraft:copper_ingot": {"protocol_id": 1},
        "minecraft:redstone_ore": {"protocol_id": 2},
        "minecraft:redstone": {"protocol_id": 3},
        "minecraft:furnace": {"protocol_id": 4},
        "minecraft:blast_furnace": {"protocol_id": 5},
        "minecraft:leather_helmet": {"protocol_id": 6},
        "minecraft:crafting_table": {"protocol_id": 7},
        "minecraft:arrow": {"protocol_id": 8},
        "minecraft:lingering_potion": {"protocol_id": 9},
        "minecraft:tipped_arrow": {"protocol_id": 10}
      }},
      "minecraft:data_component_type": {"entries": {
        "minecraft:dye": {"protocol_id": 46}
      }},
      "minecraft:slot_display": {"entries": {
        "minecraft:empty": {"protocol_id": 0},
        "minecraft:any_fuel": {"protocol_id": 1},
        "minecraft:with_any_potion": {"protocol_id": 2},
        "minecraft:only_with_component": {"protocol_id": 3},
        "minecraft:item": {"protocol_id": 4},
        "minecraft:item_stack": {"protocol_id": 5},
        "minecraft:tag": {"protocol_id": 6},
        "minecraft:dyed": {"protocol_id": 7},
        "minecraft:smithing_trim": {"protocol_id": 8},
        "minecraft:with_remainder": {"protocol_id": 9},
        "minecraft:composite": {"protocol_id": 10}
      }},
      "minecraft:recipe_display": {"entries": {
        "minecraft:crafting_shapeless": {"protocol_id": 0},
        "minecraft:crafting_shaped": {"protocol_id": 1},
        "minecraft:furnace": {"protocol_id": 2},
        "minecraft:stonecutter": {"protocol_id": 3},
        "minecraft:smithing": {"protocol_id": 4}
      }},
      "minecraft:recipe_book_category": {"entries": {
        "minecraft:crafting_building_blocks": {"protocol_id": 0},
        "minecraft:crafting_redstone": {"protocol_id": 1},
        "minecraft:crafting_equipment": {"protocol_id": 2},
        "minecraft:crafting_misc": {"protocol_id": 3},
        "minecraft:furnace_food": {"protocol_id": 4},
        "minecraft:furnace_blocks": {"protocol_id": 5},
        "minecraft:furnace_misc": {"protocol_id": 6},
        "minecraft:blast_furnace_blocks": {"protocol_id": 7},
        "minecraft:blast_furnace_misc": {"protocol_id": 8},
        "minecraft:smoker_food": {"protocol_id": 9},
        "minecraft:stonecutter": {"protocol_id": 10},
        "minecraft:smithing": {"protocol_id": 11},
        "minecraft:campfire": {"protocol_id": 12}
      }}
    }"#;

    /// A resources dir with those registries and the given recipe files.
    fn resources(name: &str, recipes: &[(&str, &str)]) -> PathBuf {
        let root =
            std::env::temp_dir().join(format!("horizon-recipe-book-{name}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        let dir = root.join("data/minecraft/recipe");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(root.join("registries.json"), REGISTRIES).unwrap();
        std::fs::write(root.join("items.json"), "{}").unwrap();
        for (id, json) in recipes {
            std::fs::write(dir.join(format!("{id}.json")), json).unwrap();
        }
        root
    }

    /// The server's sync over `root`, and the one entry of `id` read back as
    /// the client's `RecipeBookEntry::read` reads it.
    fn entry(root: &std::path::Path, id: &str) -> (SyncData, RecipeBookEntry) {
        let defaults = horizon_world::item_defaults::read(root).unwrap();
        let sync = SyncData::load(
            root,
            &horizon_world::loot::PackOverlay::NONE,
            &defaults,
            &crate::test_resources::server_sources(root, &horizon_world::loot::PackOverlay::NONE),
        )
        .unwrap();
        let entries = sync
            .advancements
            .book_entries(id, &sync, NOTIFY_AND_HIGHLIGHT);
        assert_eq!(entries.len(), 1, "{id} has one display");
        let mut r = Reader::new(&entries[0]);
        let entry = RecipeBookEntry::read(&mut r).unwrap();
        assert_eq!(r.remaining(), 0, "the entry ends with its flags");
        (sync, entry)
    }

    #[test]
    fn tick_grants_wait_for_listener_before_reward_and_recheck_progress() {
        use crate::advancements::{Advancement, Criterion, Display, Frame, Rewards};
        let mut tree = Tree::default();
        tree.list.push(Advancement {
            id: "test:tick".into(),
            parent: None,
            display: Some(Display {
                icon: "minecraft:air".into(),
                title: serde_json::json!("Title"),
                description: serde_json::json!("Description"),
                frame: Frame::Task,
                background: None,
                show_toast: true,
                announce: false,
                hidden: false,
            }),
            criteria: ["first", "second"]
                .into_iter()
                .map(|name| Criterion {
                    name: name.into(),
                    trigger: "minecraft:tick".into(),
                    conditions: Value::Null.into(),
                })
                .collect(),
            requirements: vec![vec!["first".into()], vec!["second".into()]],
            rewards: Rewards {
                recipes: vec!["test:reward".into()],
                ..Default::default()
            },
        });
        let mut sync = SyncData::empty();
        sync.advancements.kids = tree.children();
        sync.advancements.layout = tree.layout();
        sync.advancements.tree = std::sync::Arc::new(tree);
        let advancement = &sync.advancements;
        let mut progress = Progress::default();
        let mut book = Settings::default();
        let candidates = advancement.tick_candidates(&progress);
        assert_eq!(candidates.len(), 2);
        let was_done = advancement
            .grant_tick(&mut progress, &candidates[0], 12_345)
            .unwrap();
        assert!(progress.has("test:tick", "first"));
        assert!(!book.knows("test:reward"));
        advancement.reward_tick(&sync, &progress, &mut book, &candidates[0], was_done);
        assert!(!book.knows("test:reward"));
        let was_done = advancement
            .grant_tick(&mut progress, &candidates[1], 12_345)
            .unwrap();
        assert!(progress.has("test:tick", "second"));
        // This is where the Game invokes the mod listener: the criterion is
        // visible, and the completion reward is still absent.
        assert!(!book.knows("test:reward"));
        advancement.reward_tick(&sync, &progress, &mut book, &candidates[1], was_done);
        assert!(book.knows("test:reward"));
        assert!(
            advancement
                .grant_tick(&mut progress, &candidates[1], 12_345)
                .is_none()
        );
        assert!(advancement.tick_candidates(&progress).is_empty());
        let (staged, _) = advancement.first_snapshot(&sync, &progress, &candidates, 12_345);
        let original = advancement.first_tick(
            &sync,
            12_345,
            &mut Progress::default(),
            &mut Settings::default(),
        );
        assert_eq!(
            staged, original.update_advancements,
            "the staged first packet keeps the vanilla timestamp"
        );
    }

    #[test]
    fn content_recipe_unlock_sends_a_display() {
        let root = resources("content_display", &[]);
        std::fs::write(
            root.join(horizon_items::content_namespaces::MARKER),
            br#"["example"]"#,
        )
        .unwrap();
        let dir = root.join("data/example/recipe");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("test.json"), r#"{"type":"minecraft:crafting_shaped","pattern":["X"],"key":{"X":"minecraft:raw_copper"},"result":{"id":"minecraft:copper_ingot"}}"#).unwrap();
        let (sync, display) = entry(&root, "example:test");
        assert_eq!(display.id, 0);
        assert_eq!(
            display.requirements,
            Some(vec![HolderSet::Items(vec![
                sync.id("minecraft:item", "minecraft:raw_copper").unwrap()
            ])])
        );
        std::fs::remove_dir_all(root).unwrap();
    }

    /// A shaped recipe whose key uses one of NeoForge's ingredient shapes
    /// reaches the client with the shape's items, not an empty list.
    #[test]
    fn a_neoforge_ingredient_in_the_key_reaches_the_client_with_items() {
        let root = resources(
            "compound_key",
            &[(
                "compound_key",
                r#"{"type":"minecraft:crafting_shaped",
                "pattern":["X"],
                "key":{"X":{"type":"neoforge:compound","children":["minecraft:raw_copper","minecraft:redstone"]}},
                "result":{"id":"minecraft:copper_ingot"}}"#,
            )],
        );
        let (sync, e) = entry(&root, "minecraft:compound_key");
        let item = |n: &str| sync.id("minecraft:item", n).unwrap();
        let raw = item("minecraft:raw_copper");
        let redstone = item("minecraft:redstone");
        let req = e.requirements.as_ref().unwrap();
        assert_eq!(req.len(), 1, "one cell: {req:?}");
        match &req[0] {
            HolderSet::Items(items) => {
                assert!(
                    items.contains(&raw) && items.contains(&redstone),
                    "the compound's items: {items:?}"
                );
            }
            other => panic!("not an item list: {other:?}"),
        }
        let _ = std::fs::remove_dir_all(&root);
    }

    /// A recipe whose ingredient kind no loader knows stays out of the book:
    /// the server does not load it, and an empty ingredient slot in its
    /// place would mislead the client.
    /// The shared probe: a recipe the player crafts is learned by the
    /// name the crafting copy hands out, and rejoining sends what the
    /// book knows.
    fn crafted_recipe_reaches_the_book(name: &str, pack: bool) {
        let shaped = r#"{"type":"minecraft:crafting_shaped","pattern":["X"],
            "key":{"X":"minecraft:raw_copper"},
            "result":{"id":"minecraft:copper_ingot"}}"#;
        let root = if pack {
            resources(name, &[])
        } else {
            resources(name, &[(name, shaped)])
        };
        let packs = pack.then(|| {
            vec![(
                format!("recipe/minecraft:{name}"),
                vec![shaped.as_bytes().to_vec()],
            )]
        });
        let overlay = match &packs {
            Some(p) => horizon_world::loot::PackOverlay::new(p),
            None => horizon_world::loot::PackOverlay::NONE,
        };
        let defaults = horizon_world::item_defaults::read(&root).unwrap();
        let sync = SyncData::load(
            &root,
            &overlay,
            &defaults,
            &crate::test_resources::server_sources(&root, &overlay),
        )
        .unwrap();
        // What the craft hands the book: find_with over the crafting
        // copy, the way award_crafted calls it.
        let items = crate::items::Items::catalog(&root, &overlay, &defaults).unwrap();
        let recipes = crate::crafting::Recipes::load(
            &root,
            &items,
            &overlay,
            &crate::test_resources::server_load(),
        )
        .unwrap();
        let grid = vec![Some(horizon_items::items::ItemStack {
            item: "minecraft:raw_copper".into(),
            count: 1,
            damage: 0,
            extra: None,
        })];
        let (found, _) = recipes
            .find_with(
                crate::test_resources::server_loop_context(),
                &grid,
                1,
                &|_| None,
            )
            .unwrap_or_else(|| panic!("{name}: the recipe matches a grid"));
        assert_eq!(
            found, name,
            "{name}: the crafting copy names it bare, folder and pack alike"
        );
        // The book learns what the craft awards; rejoining sends it.
        let mut book = crate::recipe_book::Settings::default();
        let (_, unlocked) = book.add_recipes(&sync.advancements.displays, &[found.to_owned()]);
        assert_eq!(
            unlocked,
            [format!("minecraft:{name}")],
            "{name}: the book knows it under its whole id"
        );
        let bytes = sync.advancements.initial_recipe_book(&book, &sync);
        let mut r = Reader::new(&bytes);
        let add =
            <horizon_protocol::packets::recipes::RecipeBookAdd as horizon_protocol::buf::Codec<
                horizon_protocol::packets::recipes::RecipeBookAdd,
            >>::read(&mut r)
            .unwrap();
        assert!(
            !add.entries.is_empty(),
            "{name}: the crafted recipe reaches the book after rejoining"
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn a_folder_recipe_unlocked_by_crafting_shows_in_the_book() {
        crafted_recipe_reaches_the_book("folder_recipe", false);
    }

    #[test]
    fn a_pack_recipe_unlocked_by_crafting_shows_in_the_book() {
        crafted_recipe_reaches_the_book("pack_recipe", true);
    }

    #[test]
    fn an_owned_content_recipe_reaches_the_client_book() {
        let recipe = r#"{"type":"minecraft:crafting_shapeless","ingredients":["minecraft:raw_copper"],"result":{"id":"minecraft:copper_ingot","count":2}}"#;
        let root = resources("content_namespace", &[("control", recipe)]);
        let dir = root.join("data/recipe_pilot/recipe");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("press.json"), recipe).unwrap();
        std::fs::write(
            root.join(horizon_items::content_namespaces::MARKER),
            br#"["recipe_pilot"]"#,
        )
        .unwrap();
        let (sync, e) = entry(&root, "recipe_pilot:press");
        assert_eq!(
            e.id,
            sync.advancements
                .displays
                .first_display("recipe_pilot:press")
                .unwrap()
        );
        match e.display {
            RecipeDisplay::Shapeless { result, .. } => {
                assert_eq!(result, SlotDisplay::ItemStack(Stack::new(1, 2)));
            }
            other => panic!("not a shapeless content recipe: {other:?}"),
        }
        let _ = entry(&root, "minecraft:control");
        std::fs::remove_dir_all(&root).unwrap();
    }

    /// DyeRecipe.display: the target, then the dyes kept to what carries the
    /// DYE component, the demo of dyeing the target with one, a crafting
    /// table; its placement is the target and the dye.
    #[test]
    fn a_dye_recipe_reaches_the_book_as_its_dyed_demo() {
        let root = resources(
            "dye_recipe",
            &[(
                "leather_helmet_dyed",
                r##"{"type":"minecraft:crafting_dye","dye":"#minecraft:dyes",
                "group":"dyed_armor","result":{"id":"minecraft:leather_helmet"},
                "target":"minecraft:leather_helmet"}"##,
            )],
        );
        let (sync, e) = entry(&root, "minecraft:leather_helmet_dyed");
        let item = |n: &str| sync.id("minecraft:item", n).unwrap();
        let leather = item("minecraft:leather_helmet");
        let dye = SlotDisplay::OnlyWithComponent(
            Box::new(SlotDisplay::Tag(HolderSet::Tag("minecraft:dyes".into()))),
            sync.id("minecraft:data_component_type", "minecraft:dye")
                .unwrap(),
        );
        assert_eq!(
            e.display,
            RecipeDisplay::Shapeless {
                ingredients: vec![
                    SlotDisplay::Tag(HolderSet::Items(vec![leather])),
                    dye.clone(),
                ],
                result: SlotDisplay::Dyed {
                    dye: Box::new(dye),
                    target: Box::new(SlotDisplay::Tag(HolderSet::Items(vec![leather]))),
                },
                station: SlotDisplay::Item(item("minecraft:crafting_table")),
            }
        );
        assert_eq!(
            e.requirements,
            Some(vec![
                HolderSet::Items(vec![leather]),
                HolderSet::Tag("minecraft:dyes".into()),
            ])
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    /// ImbueRecipe.display: a 3×3 of four materials, the source kept to any
    /// potion, four materials again; the result is potion-wrapped, and the
    /// source sits in the middle of the placement.
    #[test]
    fn an_imbue_recipe_reaches_the_book_with_any_potion() {
        let root = resources(
            "imbue_recipe",
            &[(
                "tipped_arrow",
                r#"{"type":"minecraft:crafting_imbue","material":"minecraft:arrow",
                "result":{"count":8,"id":"minecraft:tipped_arrow"},
                "source":"minecraft:lingering_potion"}"#,
            )],
        );
        let (sync, e) = entry(&root, "minecraft:tipped_arrow");
        let item = |n: &str| sync.id("minecraft:item", n).unwrap();
        let material = SlotDisplay::Tag(HolderSet::Items(vec![item("minecraft:arrow")]));
        let source = SlotDisplay::Tag(HolderSet::Items(vec![item("minecraft:lingering_potion")]));
        let mut cells = vec![material.clone(); 4];
        cells.push(SlotDisplay::WithAnyPotion(Box::new(source.clone())));
        cells.extend(std::iter::repeat_n(material, 4));
        assert_eq!(
            e.display,
            RecipeDisplay::Shaped {
                width: 3,
                height: 3,
                ingredients: cells,
                result: SlotDisplay::WithAnyPotion(Box::new(SlotDisplay::ItemStack(Stack::new(
                    item("minecraft:tipped_arrow"),
                    8,
                )))),
                station: SlotDisplay::Item(item("minecraft:crafting_table")),
            }
        );
        let arrow = HolderSet::Items(vec![item("minecraft:arrow")]);
        let potion = HolderSet::Items(vec![item("minecraft:lingering_potion")]);
        assert_eq!(
            e.requirements,
            Some(vec![
                arrow.clone(),
                arrow.clone(),
                arrow.clone(),
                arrow.clone(),
                potion,
                arrow.clone(),
                arrow.clone(),
                arrow.clone(),
                arrow,
            ])
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn a_recipe_with_an_unknown_ingredient_kind_stays_out_of_the_book() {
        let root = resources(
            "mymod_kind",
            &[(
                "mymod_kind",
                r#"{"type":"minecraft:crafting_shaped",
                "pattern":["X"],
                "key":{"X":{"type":"mymod:x"}},
                "result":{"id":"minecraft:copper_ingot"}}"#,
            )],
        );
        let defaults = horizon_world::item_defaults::read(&root).unwrap();
        let sync = SyncData::load(
            &root,
            &horizon_world::loot::PackOverlay::NONE,
            &defaults,
            &crate::test_resources::server_sources(&root, &horizon_world::loot::PackOverlay::NONE),
        )
        .unwrap();
        assert!(
            !sync
                .advancements
                .recipes
                .contains_key("minecraft:mymod_kind"),
            "the network copy drops the recipe"
        );
        assert!(
            sync.advancements
                .book_entries("minecraft:mymod_kind", &sync, NOTIFY_AND_HIGHLIGHT)
                .is_empty()
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    /// The property sets and the stonecutter read a NeoForge shape's items
    /// too, not an empty slot: UpdateRecipes carries them.
    #[test]
    fn update_recipes_sends_a_neoforge_shapes_items() {
        let root = resources(
            "compound_sets",
            &[
                (
                    "compound_smelting",
                    r#"{"type":"minecraft:smelting",
                    "ingredient":{"type":"neoforge:compound","children":["minecraft:raw_copper","minecraft:redstone"]},
                    "result":{"id":"minecraft:copper_ingot"}}"#,
                ),
                (
                    "compound_stonecutting",
                    r#"{"type":"minecraft:stonecutting",
                    "ingredient":{"type":"neoforge:compound","children":["minecraft:raw_copper"]},
                    "result":{"id":"minecraft:copper_ingot"}}"#,
                ),
            ],
        );
        let defaults = horizon_world::item_defaults::read(&root).unwrap();
        let sync = SyncData::load(
            &root,
            &horizon_world::loot::PackOverlay::NONE,
            &defaults,
            &crate::test_resources::server_sources(&root, &horizon_world::loot::PackOverlay::NONE),
        )
        .unwrap();
        let item = |n: &str| sync.id("minecraft:item", n).unwrap();
        let raw = item("minecraft:raw_copper");
        let redstone = item("minecraft:redstone");
        let mut r = Reader::new(&sync.recipes);
        // The property sets, then the stonecutter's recipes.
        let mut furnace_input = None;
        for _ in 0..r.varint().unwrap() {
            let key = r.string(64).unwrap();
            let ids: Vec<i32> = (0..r.varint().unwrap())
                .filter_map(|_| r.varint().ok())
                .collect();
            if key == "minecraft:furnace_input" {
                furnace_input = Some(ids);
            }
        }
        let ids = furnace_input.expect("furnace_input set present");
        assert!(
            ids.contains(&raw) && ids.contains(&redstone),
            "the compound's items in furnace_input: {ids:?}"
        );
        // The stonecutter's entry: the compound's items, then the result.
        let stone = r.varint().unwrap();
        assert_eq!(stone, 1, "one stonecutting recipe");
        let len = r.varint().unwrap();
        assert!(len >= 2, "an item list, not empty ({len}) nor a tag");
        assert_eq!(len - 1, 1, "the compound's one item");
        assert_eq!(r.varint().unwrap(), raw);
        let _ = std::fs::remove_dir_all(&root);
    }

    /// The stonecutter's recipes go out in registration order (path, then
    /// namespace): a guest's button picks by position in the host's list,
    /// which keeps that order too.
    #[test]
    fn update_recipes_lists_the_stonecutter_in_registration_order() {
        let cut = |input: &str| {
            format!(
                r#"{{"type":"minecraft:stonecutting","ingredient":"{input}",
                "result":{{"id":"minecraft:copper_ingot"}}}}"#
            )
        };
        let vanilla = cut("minecraft:raw_copper");
        let root = resources("stonecutter_order", &[("z_cut", vanilla.as_str())]);
        let packs = [(
            "recipe/pack:a_cut".to_owned(),
            vec![cut("minecraft:redstone").into_bytes()],
        )];
        let overlay = horizon_world::loot::PackOverlay::new(&packs);
        let defaults = horizon_world::item_defaults::read(&root).unwrap();
        let sync = SyncData::load(
            &root,
            &overlay,
            &defaults,
            &crate::test_resources::server_sources(&root, &overlay),
        )
        .unwrap();
        let item = |n: &str| sync.id("minecraft:item", n).unwrap();
        let mut r = Reader::new(&sync.recipes);
        for _ in 0..r.varint().unwrap() {
            r.string(64).unwrap();
            for _ in 0..r.varint().unwrap() {
                r.varint().unwrap();
            }
        }
        let mut inputs = Vec::new();
        for _ in 0..r.varint().unwrap() {
            // An item list (its length plus one), then the result's slot
            // display: its type, item, count and two empty component lists.
            let len = r.varint().unwrap();
            inputs.push((1..len).map(|_| r.varint().unwrap()).collect::<Vec<_>>());
            for _ in 0..5 {
                r.varint().unwrap();
            }
        }
        assert_eq!(
            inputs,
            [
                vec![item("minecraft:redstone")],
                vec![item("minecraft:raw_copper")]
            ]
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    /// A world's own load over the data its packs gave (`SyncData::load_over`, which keeps
    /// that data's recipes) sends what a full read of the same packs sends: their recipes too.
    #[test]
    fn a_world_load_over_its_packs_data_sends_what_a_full_read_does() {
        let cut = |input: &str| {
            format!(
                r#"{{"type":"minecraft:stonecutting","ingredient":"{input}",
                "result":{{"id":"minecraft:copper_ingot"}}}}"#
            )
        };
        let vanilla_cut = cut("minecraft:raw_copper");
        let root = resources("load_over", &[("z_cut", vanilla_cut.as_str())]);
        let packs = [(
            "recipe/pack:a_cut".to_owned(),
            vec![cut("minecraft:redstone").into_bytes()],
        )];
        let overlay = horizon_world::loot::PackOverlay::new(&packs);
        let vanilla = SyncData::load(
            &root,
            &horizon_world::loot::PackOverlay::NONE,
            &horizon_world::item_defaults::read(&root).unwrap(),
            &crate::test_resources::server_sources(&root, &horizon_world::loot::PackOverlay::NONE),
        )
        .unwrap();
        let packed = SyncData::load(
            &root,
            &overlay,
            &horizon_world::item_defaults::read(&root).unwrap(),
            &crate::test_resources::server_sources(&root, &overlay),
        )
        .unwrap();
        let over = SyncData::load_over(
            &root,
            &overlay,
            None,
            &packed,
            &horizon_world::item_defaults::read(&root).unwrap(),
            &crate::test_resources::server_sources(&root, &overlay),
        )
        .unwrap();
        let full = SyncData::load_with_kept(
            &root,
            &overlay,
            None,
            Some(&packed),
            &horizon_world::item_defaults::read(&root).unwrap(),
            &crate::test_resources::server_sources(&root, &overlay),
        )
        .unwrap();
        assert_ne!(full.recipes, vanilla.recipes, "the pack's recipe is sent");
        assert_eq!(over.recipes, full.recipes);
        assert_eq!(over.advancements.recipes, full.advancements.recipes);
        let _ = std::fs::remove_dir_all(&root);
    }

    /// `RecipeManager.getRecipeFromDisplay`, which
    /// `handleRecipeBookSeenRecipePacket` asks: the display ids are numbered
    /// over the recipes in id order, so display 0 is the first recipe and the
    /// id past the last display names nothing.
    #[test]
    fn a_display_id_names_the_recipe_it_was_numbered_for() {
        let root = resources(
            "seen_display",
            &[
                (
                    "aaa_shaped",
                    r#"{"type":"minecraft:crafting_shaped","pattern":["X"],
                        "key":{"X":"minecraft:raw_copper"},
                        "result":{"id":"minecraft:copper_ingot"}}"#,
                ),
                (
                    "bbb_smelting",
                    r#"{"type":"minecraft:smelting","cookingtime":200,"experience":0.7,
                        "ingredient":"minecraft:raw_copper",
                        "result":{"id":"minecraft:copper_ingot"}}"#,
                ),
            ],
        );
        let defaults = horizon_world::item_defaults::read(&root).unwrap();
        let sync = SyncData::load(
            &root,
            &horizon_world::loot::PackOverlay::NONE,
            &defaults,
            &crate::test_resources::server_sources(&root, &horizon_world::loot::PackOverlay::NONE),
        )
        .unwrap();
        assert_eq!(
            sync.advancements.recipe_of_display(0),
            Some("minecraft:aaa_shaped")
        );
        assert_eq!(
            sync.advancements.recipe_of_display(1),
            Some("minecraft:bbb_smelting")
        );
        assert_eq!(
            sync.advancements.recipe_of_display(2),
            None,
            "past the last display"
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn smelting_reaches_the_furnace_book() {
        let root = resources(
            "smelting",
            &[(
                "copper_ingot_from_smelting_raw_copper",
                r#"{"type":"minecraft:smelting","cookingtime":200,"experience":0.7,
                    "group":"copper_ingot","ingredient":"minecraft:raw_copper",
                    "result":{"id":"minecraft:copper_ingot"}}"#,
            )],
        );
        let (sync, e) = entry(&root, "minecraft:copper_ingot_from_smelting_raw_copper");
        let item = |n: &str| sync.id("minecraft:item", n).unwrap();
        // The fixture's only recipe: display ids are numbered over the sorted ids.
        assert_eq!(e.id, 0);
        assert_eq!(
            e.category,
            sync.id("minecraft:recipe_book_category", "minecraft:furnace_misc")
                .unwrap()
        );
        assert_eq!(e.group, 1, "copper_ingot is the first group");
        assert_eq!(e.flags, NOTIFY_AND_HIGHLIGHT);
        assert_eq!(
            e.requirements,
            Some(vec![HolderSet::Items(vec![item("minecraft:raw_copper")])])
        );
        let RecipeDisplay::Furnace {
            ingredient,
            fuel,
            result,
            station,
            duration,
            experience,
        } = e.display
        else {
            panic!("a smelting recipe shows a furnace display");
        };
        assert_eq!(
            ingredient,
            SlotDisplay::Tag(HolderSet::Items(vec![item("minecraft:raw_copper")]))
        );
        assert_eq!(fuel, SlotDisplay::AnyFuel);
        assert_eq!(
            result,
            SlotDisplay::ItemStack(Stack::new(item("minecraft:copper_ingot"), 1))
        );
        assert_eq!(station, SlotDisplay::Item(item("minecraft:furnace")));
        assert_eq!(duration, 200);
        assert_eq!(experience, 0.7);
        let _ = std::fs::remove_dir_all(&root);
    }

    /// A recipe filter's `replace_input` (#5910) reaches the book swapped:
    /// the book writes from the network copy, so the swap must have run
    /// there, once, before the ingredient normalization. A world's pack
    /// carries the filter (the way the game reads them).
    #[test]
    fn a_recipe_filters_swapped_input_shows_swapped_in_the_book() {
        let root = resources(
            "filter_swap",
            &[(
                "copper_ingot_from_smelting_raw_copper",
                r#"{"type":"minecraft:smelting","cookingtime":200,"experience":0.7,
                    "ingredient":"minecraft:raw_copper",
                    "result":{"id":"minecraft:copper_ingot"}}"#,
            )],
        );
        let packs = vec![(
            "recipe_filter/minecraft:swap".to_owned(),
            vec![
                br#"{"filters":[{"id":"minecraft:copper_ingot_from_smelting_raw_copper",
                "replace_input":{"from":"minecraft:raw_copper","to":"minecraft:redstone"}}]}"#
                    .to_vec(),
            ],
        )];
        let overlay = horizon_world::loot::PackOverlay::new(&packs);
        let defaults = horizon_world::item_defaults::read(&root).unwrap();
        let sync = SyncData::load(
            &root,
            &overlay,
            &defaults,
            &crate::test_resources::server_sources(&root, &overlay),
        )
        .unwrap();
        let entries = sync.advancements.book_entries(
            "minecraft:copper_ingot_from_smelting_raw_copper",
            &sync,
            NOTIFY_AND_HIGHLIGHT,
        );
        assert_eq!(entries.len(), 1, "the recipe has one display");
        let mut r = Reader::new(&entries[0]);
        let e = RecipeBookEntry::read(&mut r).unwrap();
        assert_eq!(r.remaining(), 0, "the entry ends with its flags");
        let item = |n: &str| sync.id("minecraft:item", n).unwrap();
        assert_eq!(
            e.requirements,
            Some(vec![HolderSet::Items(vec![item("minecraft:redstone")])]),
            "the filter's swapped input, not the file's"
        );
        let RecipeDisplay::Furnace { ingredient, .. } = e.display else {
            panic!("a smelting recipe shows a furnace display");
        };
        assert_eq!(
            ingredient,
            SlotDisplay::Tag(HolderSet::Items(vec![item("minecraft:redstone")])),
            "the display shows the swapped input too"
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn blasting_reaches_the_blast_furnace_book() {
        let root = resources(
            "blasting",
            &[(
                "redstone_from_blasting_redstone_ore",
                r#"{"type":"minecraft:blasting","category":"blocks","cookingtime":200,
                    "experience":0.7,"group":"redstone",
                    "ingredient":"minecraft:redstone_ore","result":{"id":"minecraft:redstone"}}"#,
            )],
        );
        let (sync, e) = entry(&root, "minecraft:redstone_from_blasting_redstone_ore");
        let item = |n: &str| sync.id("minecraft:item", n).unwrap();
        assert_eq!(e.id, 0);
        assert_eq!(
            e.category,
            sync.id(
                "minecraft:recipe_book_category",
                "minecraft:blast_furnace_blocks"
            )
            .unwrap()
        );
        let RecipeDisplay::Furnace {
            ingredient,
            station,
            duration,
            experience,
            ..
        } = e.display
        else {
            panic!("a blasting recipe shows a furnace display");
        };
        assert_eq!(
            ingredient,
            SlotDisplay::Tag(HolderSet::Items(vec![item("minecraft:redstone_ore")]))
        );
        assert_eq!(station, SlotDisplay::Item(item("minecraft:blast_furnace")));
        assert_eq!(duration, 200);
        assert_eq!(experience, 0.7);
        let _ = std::fs::remove_dir_all(&root);
    }

    /// Every recipe the game has, as a Horizon server sends it to a Horizon
    /// client: the client's own book keeps its entries, none is taken from the
    /// packet (a regression of parity with Horizon on both sides otherwise).
    /// Needs the prepared resources (`HORIZON_TEST_RESOURCES`, or the checkout's
    /// `.local`); passes without them.
    #[test]
    fn a_horizon_server_of_the_real_recipes_leaves_the_clients_book_as_it_is() {
        use crate::{
            crafting::Recipes,
            items::Items,
            recipe_book::{Book, PacketNames, RecipeIndex},
        };
        let root = std::env::var_os("HORIZON_TEST_RESOURCES")
            .map(PathBuf::from)
            .unwrap_or_else(|| {
                Path::new(env!("CARGO_MANIFEST_DIR"))
                    .join("../../.local/horizon-client")
                    .join(horizon_core::VANILLA_VERSION)
            });
        if !root.join("registries.json").exists() {
            return;
        }
        let none = &horizon_world::loot::PackOverlay::NONE;
        let sync = SyncData::load(
            &root,
            none,
            &horizon_world::item_defaults::read(&root).unwrap(),
            &crate::test_resources::server_sources(&root, none),
        )
        .unwrap();
        let items = Items::catalog(
            &root,
            none,
            &horizon_world::item_defaults::read(&root).unwrap(),
        )
        .unwrap();
        let recipes =
            Recipes::load(&root, &items, none, &crate::test_resources::server_load()).unwrap();
        let mut book = Book::build(&recipes, &items);
        book.set_display_ids(&RecipeIndex::load(&root, none));
        let before: Vec<(String, i32, Option<String>)> = book
            .entries
            .iter()
            .map(|e| (e.id.clone(), e.display_id, e.group.clone()))
            .collect();
        let mut sent = Vec::new();
        for id in sync.advancements.recipes.keys() {
            for bytes in sync.advancements.book_entries(id, &sync, 0) {
                sent.push(RecipeBookEntry::read(&mut Reader::new(&bytes)).unwrap());
            }
        }
        assert!(sent.len() > 1000, "{} entries sent", sent.len());
        let item = |id: i32| {
            sync.builtin
                .get("minecraft:item")
                .and_then(|i| i.name(id))
                .map(str::to_owned)
        };
        let category = |id: i32| {
            sync.builtin
                .get("minecraft:recipe_book_category")
                .and_then(|i| i.name(id))
                .map(str::to_owned)
        };
        let tag = |name: &str| items.item_tag_order.get(name).cloned().unwrap_or_default();
        book.use_server_entries(
            &sent,
            &PacketNames {
                item: &item,
                category: &category,
                tag: &tag,
            },
        );
        let after: Vec<(String, i32, Option<String>)> = book
            .entries
            .iter()
            .map(|e| (e.id.clone(), e.display_id, e.group.clone()))
            .collect();
        let changed: Vec<_> = before
            .iter()
            .zip(&after)
            .filter(|(b, a)| b != a)
            .take(10)
            .collect();
        assert_eq!(after.len(), before.len(), "entries were added");
        assert!(changed.is_empty(), "entries changed: {changed:?}");
        assert!(book.server_requirements.is_empty());
    }
}

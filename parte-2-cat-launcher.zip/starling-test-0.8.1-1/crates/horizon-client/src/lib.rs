//! Gameplay and startup, above the reusable client library.
// The Android hooks (android.rs) call into the activity through JNI and the C library.
// No `#![recursion_limit]` or other inner attribute horizon-mixins doesn't know here: the
// launcher's horizon-mixins then rejects every native mod targeting this crate (#8169).
#![cfg_attr(not(target_os = "android"), forbid(unsafe_code))]
extern crate self as horizon_client;
pub use horizon_client_lib::*;
#[cfg(target_os = "android")]
pub mod android;
/// Cat Launcher's bridge (HTML -> Java -> JNI -> here): accounts, downloads, skins, versions.
#[cfg(target_os = "android")]
pub mod cat_bridge;
#[doc(hidden)]
pub mod entry;

// The game's allocator lives in the library, not the executable: the prebuilt game (#589) is this crate as a
// dylib, and the allocator must be the one its code and the mods' executable share. The Windows archive builds
// with `system-allocator`: std's DLL keeps its own allocator there, which everything then shares (#2394).
#[cfg(not(any(feature = "system-allocator", feature = "alloc-census")))]
#[global_allocator]
static ALLOCATOR: horizon_threads::Allocator = horizon_threads::ALLOCATOR;
#[cfg(all(feature = "alloc-census", not(feature = "system-allocator")))]
#[global_allocator]
static ALLOCATOR: horizon_threads::CensusAllocator = horizon_threads::CensusAllocator;
pub mod game;

pub mod diagnostics;
pub mod performance;

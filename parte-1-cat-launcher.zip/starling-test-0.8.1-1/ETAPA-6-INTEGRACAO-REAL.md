# ETAPA 6 - Cat Launcher (interface HTML) + motor real do Starling — NÃO COMPILADO, NÃO TESTADO NO APARELHO

## Como o projeto realmente é
- O app Android é o crate `horizon-android` (cdylib NativeActivity) = `crates/horizon-client`. O jogo e a tela de preparo
  (`game/starling/setup/mod.rs`) rodam dentro dele. Gradle não existe: o APK sai de `packaging/android/build_apk.py`
  (cargo-ndk + javac + d8 + aapt2).
- `launcher/` (GPUI, `offline_accounts.rs`, `account.rs`...) é o launcher de DESKTOP: fora do workspace e fora do APK.
  As ETAPAS 1-2 editaram esse código; elas não chegam ao Android (e a própria ETAPA-2 diz que ele não compila).
- O motor roda UMA versão: Minecraft Java 26.3 (`Pins::starling()`). Por isso 1.8.9, 1.21.4, beta etc. não existem no motor;
  a tela de versões só lista 26.3.
- Os 3 zips eram arquivos independentes (não "partes" de um split): extraídos juntos formam `starling-test-0.8.1-1`.

## O que esta etapa integra (feito por leitura/edição)
Fluxo: ícone -> `LauncherActivity` -> `CatHomeActivity` (WebView com `assets/cat/index.html`, processo `:cat`) -> toque em Jogar ->
checagens -> `GameActivity` com o nome do jogador -> Rust `poll_setup` age como o toque em Play: baixa dos servidores oficiais os arquivos
que faltam (hash conferido, retoma e reaproveita o que já está em `files/minecraft`), prepara, abre o jogo. Erros reais aparecem na tela de preparo.
Ao sair do jogo o processo do jogo termina e o Android volta para a tela do Cat Launcher (outro processo/tarefa).

Arquivos (ver `cat-integracao.patch` + novos):
- NOVO `packaging/android/java/.../CatHomeActivity.java`: WebView, ponte `window.CatNative` (listVersions, installedVersions, installVersion,
  launch, removeVersion, saveSkin, immersive, microsoftLogin), alert/confirm, seletor de arquivo (skin PNG), botão Voltar, checagens
  reais: Android >= 8, ARM64, Vulkan 1.1, ~2 GB livres (se os arquivos ainda não foram baixados), nome 3-16 [A-Za-z0-9_], versão 26.3.
- NOVO `packaging/android/cat/index.html`: o seu Cat Launcher (design/telas/animações/contas mantidos), ligado à ponte.
- `LauncherActivity.java`: o início padrão abre a CatHomeActivity (reinício do jogo e arquivos abertos seguem direto ao jogo).
- `StarlingActivity.java`: lê o nome e chama `onCatPlay`. `android_lib.rs` + `android.rs`: JNI/estado. `setup/mod.rs`: `poll_setup` trata
  como Play (cria o perfil offline com o nome do Cat Launcher) quando a conta já estabilizou.
- `AndroidManifest.xml` e `build_apk.py`: registram a activity e empacotam `assets/cat/` (se existir `packaging/android/cat/three.min.js`, ele é usado no lugar do CDN).

## Verificado aqui
- Interface + ponte, no Chromium, com um `CatNative` SIMULADO: Jogar sem conta pede login; com conta chama `launch("26.3", sessão)`;
  erro devolvido pelo motor aparece na tela; instalar chama o motor; Voltar do Android; lista de versões vem do motor.
- `CatHomeActivity.java` compila contra stubs escritos à mão das APIs do Android (não contra o android.jar real).
- Manifesto é XML válido; `build_apk.py` passa no `py_compile`.

## NÃO verificado (sem cargo, NDK, Android SDK, rede ou aparelho neste ambiente)
Compilação Rust/NDK, compilação Java contra o SDK real, build do APK, Jogar abrir o Minecraft, download/preparo, retorno ao launcher,
travamentos, WebView com `file:///android_asset` (crypto.subtle das contas).

## Limitações conhecidas
- Só 26.3. Remover versão não é suportado pelo motor (a ponte avisa).
- A skin escolhida é salva (`files/cat-skin.json`), mas o motor ainda não a lê: aplicar no jogo exige ligar `own_skin.rs`.
- Progresso de download aparece na tela de preparo do jogo, não na barra do HTML.
- Login Microsoft/verificação de propriedade é o do jogo (na tela de preparo). O Jogar pede, uma vez, a confirmação de que há cópia legítima.

## Como testar (máquina com SDK/NDK/Rust)
    python3 packaging/android/build_apk.py --install     # aparelho ARM64, Android 8+, Vulkan 1.1
    adb logcat -s starling:* chromium:* AndroidRuntime:E
Checar: ícone abre o Cat Launcher; Criar Conta -> Personalização; Jogar sem conta pede login; Jogar com conta abre o preparo,
baixa, abre o jogo; sair do jogo volta ao Cat Launcher; segunda abertura não baixa de novo.
